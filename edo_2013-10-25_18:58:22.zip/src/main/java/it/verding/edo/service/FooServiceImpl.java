package it.verding.edo.service;

public class FooServiceImpl implements FooService {
}
