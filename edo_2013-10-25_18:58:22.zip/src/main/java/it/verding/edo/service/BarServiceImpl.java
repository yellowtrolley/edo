package it.verding.edo.service;

public class BarServiceImpl implements BarService {
}
