package it.verding.edo.service;
import org.springframework.roo.addon.layers.service.RooService;

@RooService(domainTypes = { it.verding.edo.model.Bar.class })
public interface BarService {
}
