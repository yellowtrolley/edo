package it.verding.edo.service;
import org.springframework.roo.addon.layers.service.RooService;

@RooService(domainTypes = { it.verding.edo.model.Foo.class })
public interface FooService {
}
