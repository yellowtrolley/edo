package it.verding.edo.model;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Foo.class)
public class FooDataOnDemand {
}
