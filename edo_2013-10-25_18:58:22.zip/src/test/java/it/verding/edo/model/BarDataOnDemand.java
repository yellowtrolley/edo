package it.verding.edo.model;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Bar.class)
public class BarDataOnDemand {
}
