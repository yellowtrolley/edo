package it.verding.edo.model;
import it.verding.edo.service.FooService;
import junit.framework.Assert;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Foo.class, transactional = false)
public class FooIntegrationTest {
	@Autowired FooService fooService;
	
    @Test
    public void testMarkerMethod() {


    	Foo foo = new Foo(); 
    	fooService.saveFoo(foo);
    	Assert.assertTrue (fooService.countAllFoos() > 0);

    	Foo foo2 = fooService.findFoo(foo.getId());
    	Assert.assertEquals( foo.getId(), foo2.getId());
    	foo.getBarlist().add(new Bar());
    	Assert.assertEquals(1, foo.getBarlist().size() == 1);



    }
}
